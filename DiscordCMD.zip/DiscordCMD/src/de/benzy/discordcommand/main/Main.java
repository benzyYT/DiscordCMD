/*    */ package de.benzy.discordcommand.main;
/*    */ 
import de.benzy.discordcommand.cmds.DiscordCMD;

/*    */ import org.bukkit.Bukkit;
/*    */ import org.bukkit.command.CommandExecutor;
/*    */ import org.bukkit.plugin.java.JavaPlugin;
/*    */ 
/*    */ public class Main
/*    */   extends JavaPlugin {
/*    */   public void onEnable() {
/* 11 */     reloadConfig();
/* 12 */     config();
/* 13 */     Bukkit.getPluginCommand("discord").setExecutor((CommandExecutor)new DiscordCMD(getConfig()));
/* 14 */     System.out.println("Fly aktiviert");
/*    */   }
/*    */   
/*    */   public void onDisable() {
/* 18 */     System.out.println("Fly deaktiviert");
/*    */   }
/*    */   
/*    */   public void config() {
/* 22 */     getConfig().addDefault("DiscordMSG", "&aWe also have a Discord: &cYOURDISCORDLINK");
             getConfig().addDefault("Prefix", "&7[&aDiscord&7]");
/* 25 */     getConfig().options().copyDefaults(true);
/* 26 */     saveConfig();
/*    */   }
/*    */ }
