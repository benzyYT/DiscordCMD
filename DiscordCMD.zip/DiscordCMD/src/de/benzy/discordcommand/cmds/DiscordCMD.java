/*    */ package de.benzy.discordcommand.cmds;
/*    */ 
/*    */ import org.bukkit.command.Command;
/*    */ import org.bukkit.command.CommandExecutor;
/*    */ import org.bukkit.command.CommandSender;
/*    */ import org.bukkit.configuration.file.FileConfiguration;
/*    */ import org.bukkit.entity.Player;
         import de.benzy.discordcommand.main.*;
/*    */ 
/*    */ public class DiscordCMD implements CommandExecutor {
/*    */   FileConfiguration cfg;
/*    */   
/*    */   public DiscordCMD(FileConfiguration config) {
/* 13 */     this.cfg = config;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
/* 18 */     if (!(sender instanceof Player)) {
/* 19 */       System.out.println("Du musst ein Spieler sein");
/* 20 */       return true;
/*    */     } 
/* 22 */     Player p = (Player)sender;
/* 23 */     if (!p.hasPermission("dc.cmd")) {
/* 24 */       p.sendMessage(this.cfg.getString("Prefix").replaceAll("&", "�") + " " + this.cfg.getString("NoPerm").replaceAll("&", "�"));
/* 25 */       return true; 
             } else {
            	 p.sendMessage(this.cfg.getString("Prefix").replaceAll("&", "�") + " " + this.cfg.getString("DiscordMSG").replaceAll("&", "�"));
             }
/*    */
return false;   }
/*    */ }


/* Location:              C:\Users\monik\Downloads\Fly.jar!\de\jailbreaker\commands\Fly.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */